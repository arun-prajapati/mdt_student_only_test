const String HomeRoute = '/home';
const String HomePageRoute = '/Authorization';
const String AboutUsRoute = '/about';
const String ContactUsRoute = '/contact';
const String HelpRoute = '/help';
const String SettingRoute = '/setting';
const String EpisodesRoute = '/episodes';
const String SplashRoute = '/splash';
const String WelcomeRoute = '/welcome';
const String RegisterRoute ='/register';
const String LoginRoute ='/login';
const String HighwayCodeRoute ='/highwaycode';
const String MyBookingRoute ='/mybooking';
const String BiddingRoute ='/bidding';
const String BiddingDetailRoute ='/biddingdetails';
const String BookLessionFormRoute ='/bookpackage';
const String CalendarRoute ='/calender';


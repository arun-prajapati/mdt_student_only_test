import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:main_flutter/main.dart';
import 'package:main_flutter/services/auth.dart';
import 'package:main_flutter/views/Bidding/Bidding.dart';
import 'package:main_flutter/views/Bidding/BiddingDetails.dart';
import 'package:main_flutter/views/Bookings/MyBookings.dart';
import 'package:main_flutter/views/Calendar/calendar.dart';
import 'package:main_flutter/views/DrawerScreens/AboutUs.dart';
import 'package:main_flutter/views/DrawerScreens/ContactUs.dart';
import 'package:main_flutter/views/DrawerScreens/Help.dart';
import 'package:main_flutter/views/DrawerScreens/Settings.dart';
import 'package:main_flutter/views/HighwayCode/HigwayCode.dart';
import 'package:main_flutter/views/Home/home_view.dart';
import 'package:main_flutter/views/Login/login.dart';
import 'package:main_flutter/views/Login/register.dart';
import 'package:main_flutter/views/Login/welcome.dart';
import 'package:main_flutter/views/Driver/BookLession/BookLessionForm.dart';
import 'package:main_flutter/views/Splash/splash.dart';
import 'package:provider/provider.dart';
import 'route_names.dart' as routes;

Route<dynamic> generateRoute(RouteSettings settings) {
  switch (settings.name) {
    case routes.WelcomeRoute:
      return MaterialPageRoute(builder: (context) => Welcome());
    case routes.AboutUsRoute:
      return MaterialPageRoute(builder: (context) => AboutUs());
    case routes.ContactUsRoute:
      return MaterialPageRoute(builder: (context) => ContactUs());
    case routes.HelpRoute:
      return MaterialPageRoute(builder: (context) => Help());
    case routes.SettingRoute:
      return MaterialPageRoute(builder: (context) => Settings());
   case routes.HomeRoute:
     return MaterialPageRoute(builder: (context) => HomeView());
    case routes.LoginRoute:
      return MaterialPageRoute(builder: (context) => SignInForm());
    case routes.RegisterRoute:
      return MaterialPageRoute(builder: (context) => Register());
    case routes.SplashRoute:
      return MaterialPageRoute(builder: (context) => SplashScreen());
    case routes.HomePageRoute:
      return MaterialPageRoute(builder: (context) => HomePage());
    case routes.HighwayCodeRoute:
      return MaterialPageRoute(builder: (context) => HighwayCode());
    case routes.MyBookingRoute:
      return MaterialPageRoute(builder: (context) => MyBooking());
    case routes.BiddingRoute:
      return MaterialPageRoute(builder: (context) => Biddings());
    // case routes.BiddingDetailRoute:
    //   return MaterialPageRoute(builder: (context) => BiddingDetails());
    case routes.BookLessionFormRoute:
      return MaterialPageRoute(builder: (context) => BookLessionForm());
    case routes.CalendarRoute:
      return MaterialPageRoute(builder: (context) => Calender());

//      var userName = settings.arguments as String;
//      return MaterialPageRoute(
//          builder: (context) => HomeView(userName: userName));
    default:
      return MaterialPageRoute(
        builder: (context) => Scaffold(
          body: Center(
            child: Text('No path for ${settings.name}'),
          ),
        ),
      );
  }
}
